#include <stdio.h>
#include <iostream>
#include <math.h>
#include <string.h>
#include "PlyUtility.h"
#include "View.h"
#include "PlyModel.h"
#include "BoundingBox.h"
#include "Quaternion.h"
#include "Vector.h"
#include "Arcball.h"
using namespace std;

#define PI 3.1415926535898
#define COS(th) cos(PI/180*(th))
#define SIN(th) sin(PI/180*(th))

void myReshape(int w, int h);
void myKeyBoard(unsigned char key,int x, int y);
void myMouse(int button, int state, int x, int y);
void myDisplay(void);
void myInit(void);
void windowSpecial(int key,int x,int y);
void myMouseMotion(int x, int y) ;


float rollspeed=1.5;
float zoomfactor=1.0;
//int last_mx = 0, last_my = 0, cur_mx = 0, cur_my = 0;
int arcball_on = false;
float Eye[3]={0,0,5.0};
double dim=2.0;
float th = 0;
float ph = 0;
int fov = 45;
float asp = 1;
float SCREEN_WIDTH = 1000,SCREEN_HEIGHT = 650;

Arcball arcball(SCREEN_WIDTH,SCREEN_HEIGHT,1.5);
View view;
PlyUtility ply;
PlyModel plymodel;
BoundingBox box;



void myMouse(int button, int state, int x, int y) {


    if(state==GLUT_DOWN && button==GLUT_LEFT)
    {
        arcball_on = true;
        arcball.set_current_xy(x,y);
        arcball.set_last_xy(x,y);

    }else {
        arcball_on = false;
    }

}
void myMouseMotion(int x, int y) {


    if (arcball_on) {  // if left button is pressed
        arcball.set_current_xy(x,y);
     }
    glMatrixMode(GL_MODELVIEW);
    arcball.rotateModelvthMouse(dim);
    glutPostRedisplay();


}

void myDisplay() {

    /*init called first and then reshape gets called*/

    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);


    box.draw(dim);
    plymodel.draw(ply);
    view.drawAxis(dim);
    view.markPoints(dim);


    glFlush();
}


void myInit() {


    glViewport(0,0, SCREEN_WIDTH,SCREEN_HEIGHT);


    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fov,SCREEN_WIDTH/SCREEN_HEIGHT,dim,4*dim);


    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0,0,2.5*dim, 0,0,0 , 0,1,0);

    GLfloat light_position[] = { 0.0,0.0,10.0, 0.0 };

    GLfloat light_diffuse[] = {0.75,0.68,0.5,0.0};

    glClearColor(0.0,0.0,0.0,0.0);
    glEnable(GL_NORMALIZE);
    glShadeModel (GL_SMOOTH);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    GLfloat mat_ambient[] = { 1.0, 1.0, 1.0, 0.0 };
    GLfloat mat_shininess[] = { 100.0 };
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);





    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_DEPTH_TEST);
}


int main(int argc, char *argv[]) {

    ply.readPlyFile("bunny");
    plymodel.computeNormal(ply);
    plymodel.computeCentroid(ply);
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB|GLUT_DEPTH);//use single buffer and RGB color schemes
    glutInitWindowSize(SCREEN_WIDTH,SCREEN_HEIGHT);
    glutInitWindowPosition(0,0);
    glutCreateWindow("3D MADNESS");
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glColor3f(0.0,1.0,1.0);

    //register callbacks
    glutDisplayFunc(myDisplay);
    glutReshapeFunc(myReshape);
    glutKeyboardFunc(myKeyBoard);
    glutMouseFunc(myMouse);
    glutSpecialFunc(windowSpecial);
    glutMotionFunc(myMouseMotion);


    myInit();
    glutMainLoop();

    return 0;
}



void myReshape(int w,int h)
{

    SCREEN_WIDTH=w;
    SCREEN_HEIGHT=h;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(fov,SCREEN_WIDTH/SCREEN_HEIGHT,dim,4*dim);
    glViewport(0,0, SCREEN_WIDTH,SCREEN_HEIGHT);

    arcball.set_width_height(SCREEN_WIDTH,SCREEN_HEIGHT);



}

void windowSpecial(int key,int x,int y)
{
    if (key == GLUT_KEY_RIGHT) {th =0.1;ph=0.0;}
    else if (key == GLUT_KEY_LEFT) {th =-0.1;ph=0.0;}
    else if (key == GLUT_KEY_UP) {th=0.0;ph =0.1;}
    else if (key == GLUT_KEY_DOWN){ th=0.0 ;ph =-0.1;}

    glTranslatef(th,ph,0.0);
    glutPostRedisplay();
}

void myKeyBoard(unsigned char key,int x,int y)
{    /*  Exit on ESC */
    if (key == 27) exit(0);
    /*  Change field of view angle */
    else if (key == '-' && key>1) zoomfactor=0.9;
    else if (key == '+' && key<179)zoomfactor=1.1;

    glScalef(zoomfactor,zoomfactor,zoomfactor);
    glutPostRedisplay();

}


