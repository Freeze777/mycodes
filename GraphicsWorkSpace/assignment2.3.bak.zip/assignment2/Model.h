#ifndef model_h
#define model_h

#include "PlyUtility.h"

class Model{



public:
PlyUtility *ply;

Model();
~Model();


};



#endif
