#ifndef view_h
#define view_h

#include <GL/glu.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include "PlyModel.h"
#include "BoundingBox.h"

class View{

private:
    GLfloat origin[3] = {0.0, 0.0, 0.0};

    BoundingBox box;



public:
    PlyModel *plymodel;
    void drawScene(float dim);
    void drawAxis(float dim);
    void markPoints(float dim);
    View(PlyUtility *ply){

        plymodel=new PlyModel(ply);

    }

};


#endif
