#include "Model.h"

Model::Model(){

ply=new PlyUtility();

}

Model::~Model(){


delete ply;

}
