//
//  Arcball.cpp
//  Arcball
//
//  Created by Saburo Okita on 12/03/14.
//  Copyright (c) 2014 Saburo Okita. All rights reserved.
//

#include "Arcball.h"

/**
 * Constructor.
 * @param roll_speed the speed of rotation
 */
Arcball::Arcball( int SCREEN_WIDTH, int SCREEN_HEIGHT, GLfloat roll_speed) {
    this->windowWidth  = SCREEN_WIDTH;
    this->windowHeight = SCREEN_HEIGHT;
    
    this->rollSpeed  = roll_speed;
    
  
}

void Arcball::rotateModelvthMouse(float dim){
    double * rotMatrix;
    if (cur_mx != last_mx || cur_my != last_my) {

        Vector va = get_arcball_vector(last_mx, last_my,dim);
        Vector vb = get_arcball_vector( cur_mx,  cur_my,dim);
        double angle = (180.0 / Quaternion::PI )*acos(std::min(1.0, dot(va, vb)));//in degrees
        angle=rollSpeed*angle;
        Vector axis_in_camera_coord = cross(vb, va);


        double axis_in_object_coord[3]={axis_in_camera_coord.x(),axis_in_camera_coord.y(),axis_in_camera_coord.z()};

        Quaternion quat(angle,axis_in_object_coord);

        rotMatrix=quat.rotationMatrix();
        glMultMatrixd(rotMatrix);
        free(rotMatrix);
        quat.~Quaternion();
        last_mx = cur_mx;
        last_my = cur_my;

    }
}

Vector Arcball::get_arcball_vector(int x, int y,float dim) {

    Vector P = Vector((dim/2)*x/windowWidth*2 - dim/2,
                      (dim/2)*y/windowHeight*2 - dim/2,
                      0);
    P.y(- P.y());

    float OP_squared = P.x() * P.x() + P.y() * P.y();

    if (OP_squared <= (dim/2)*(dim/2))
        P.z(sqrt((dim/2)*(dim/2)- OP_squared));  // Pythagore
    else
        P.normalize();
    return P;
}
