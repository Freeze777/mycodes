#include <stdio.h>
int main()
{
printf("%d\n",sizeof(/*unsigned long long*/ int));
return 0;
}
