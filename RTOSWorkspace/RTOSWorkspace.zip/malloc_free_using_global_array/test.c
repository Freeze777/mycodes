#include <stdio.h>
#include "functions.h"
int main()
{
printf("%d\n",sizeof(unsigned long));
return 0;
}
